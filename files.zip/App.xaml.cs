using System.Windows;

namespace ForeverSkiesSaveEditor;

public partial class App : Application
{
}
